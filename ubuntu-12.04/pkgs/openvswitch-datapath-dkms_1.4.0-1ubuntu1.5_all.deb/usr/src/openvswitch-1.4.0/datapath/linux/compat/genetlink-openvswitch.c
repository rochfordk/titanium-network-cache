#define GENL_FIRST_MCGROUP 16
#define GENL_LAST_MCGROUP  31

#include "genetlink.inc"
