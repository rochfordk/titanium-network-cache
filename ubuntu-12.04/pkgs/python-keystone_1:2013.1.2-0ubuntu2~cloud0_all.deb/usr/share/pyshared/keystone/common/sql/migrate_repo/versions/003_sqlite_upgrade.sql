alter TABLE token  ADD valid integer;
update token set valid = 1;

